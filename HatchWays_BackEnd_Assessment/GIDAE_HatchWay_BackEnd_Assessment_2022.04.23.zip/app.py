from settings import *
from route import *
from settings import *


# fetch data from the below API:
# Route: https://api.hatchways.io/assessment/blog/posts?tag=tech
# Method: Get
# Field: tag

if __name__ == ('__main__'):
    app.run()
    
